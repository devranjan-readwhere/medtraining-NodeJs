

const express = require('express')
var router = express.Router();
const mongoose = require('mongoose');
const Company = mongoose.model('Company');

router.get('/',(req,res)=>{
    res.render("company/display",{
        viewTitle : "Insert Info"
    });
});
router.post('/',(req,res)=>{
    // console.log(req.body);
    if(req.body._id == '')
        insertData(req,res);
    else
        updateData(req,res);
});

function insertData(req,res){
    var company = new Company();
    company.cname = req.body.cname;
    company.about = req.body.about;
    company.doe =req.body.doe;
    company.save((err,doc)=>{
        if(!err){
        res.redirect('company/list');
        }else{
            console.log('Error: '+err);
        }
    });
}

function updateData(req,res){
    Company.findByIdAndUpdate({ _id:req.body._id}, req.body,{new:true},(err,doc)=>{
        if(!err){
            res.redirect('company/list');
        }else{
            res.render("company/display",{
                viewTitle: 'Update Info',
                company:req.body
            });
        }
    })
}
router.get('/list',(req,res)=>{
    // res.json('Added');
    Company.find((err,docs)=>{
        if(!err){
            res.render("company/list",{
                list: docs
            });
        }
        else{
            console.log('Error: '+err);
        }
    });
});

router.get('/:id',(req,res)=>{
    Company.findById(req,params.id,(err,doc)=>{
        if(!err){
            res.render("company/display",{
                viewTitle:"Update Info",
                company:doc
            })
        }
    })
})

module.exports = router;